package com.example.fatma.news;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class Adapter extends ArrayAdapter<News> {

    public Adapter(@NonNull Context context, ArrayList<News> jsonInformation) {
        super(context,0,jsonInformation);
    }

    @NonNull
    @Override
    public View getView(int position, @NonNull View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list, parent, false);
        }

            News currentNews= getItem(position);

            TextView sectionName = listItemView.findViewById(R.id.sectionName);
        sectionName.setText(currentNews.getSectionName());

        TextView webTitleAut = listItemView.findViewById(R.id.webTitleAut);
        webTitleAut.setText(currentNews.getWebTitleAut());

        TextView Url = listItemView.findViewById(R.id.Url);
        Url.setText(currentNews.getUrl());

        TextView author = listItemView.findViewById(R.id.webTitle);
        author.setText(currentNews.getWebTitle());

        TextView date = listItemView.findViewById(R.id.date);
        date.setText(currentNews.getDate_());

        return listItemView;
        }
    }