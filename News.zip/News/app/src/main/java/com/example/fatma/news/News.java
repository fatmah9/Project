package com.example.fatma.news;

import java.util.ArrayList;

public class News extends ArrayList<News> {
    private String sectionName;
    private String webTitle;
    private String url;
    private String webPublicationDate;
    private String webTitleAut;

    public News(String sectionName, String webTitle, String url, String webPublicationDate,String webTitleAut) {
        this.sectionName = sectionName;
        this.webTitle = webTitle;
        this.url = url;
        this.webPublicationDate = webPublicationDate;
        this.webTitleAut=webTitleAut;
    }

    public String getSectionName() {
        return sectionName;
    }

    public String getDate_() {
        return webPublicationDate;
    }

    public String getWebTitle() { return webTitle;}

    public String getWebTitleAut(){return webTitleAut;}

    public String getUrl() {
        return url;
    }

}